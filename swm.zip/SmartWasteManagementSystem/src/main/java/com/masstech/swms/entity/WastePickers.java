package com.masstech.swms.entity;

public class WastePickers {
	private String address1;
	private String address2;
	private String contact;
	private String email;
	private String pincode;
	private String rf_id;
	private String username;

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getRf_id() {
		return rf_id;
	}

	public void setRf_id(String rf_id) {
		this.rf_id = rf_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return "WastePickers [address1=" + address1 + ", address2=" + address2 + ", contact=" + contact + ", email="
				+ email + ", pincode=" + pincode + ", rf_id=" + rf_id + ", username=" + username + "]";
	}

}
