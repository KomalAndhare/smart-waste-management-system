package com.masstech.swms.entity;

public class Stops {

	String area;
	String lat;
	String lon;
	String dry;
	String wet;

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLon() {
		return lon;
	}

	public void setLon(String lon) {
		this.lon = lon;
	}

	public String getDry() {
		return dry;
	}

	public void setDry(String dry) {
		this.dry = dry;
	}

	public String getWet() {
		return wet;
	}

	public void setWet(String wet) {
		this.wet = wet;
	}

	@Override
	public String toString() {
		return "Stops [area=" + area + ", lat=" + lat + ", lon=" + lon + ", dry=" + dry + ", wet=" + wet + "]";
	}

}
