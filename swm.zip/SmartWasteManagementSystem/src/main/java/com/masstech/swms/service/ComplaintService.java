package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.Complaints;
import com.masstech.swms.entity.User;

@Service
public class ComplaintService {
	private final DatabaseReference databaseReference;

	public ComplaintService() {
		databaseReference = FirebaseDatabase.getInstance().getReference("Complaints");
	}

	public List<Complaints> getComplaints() {
		List<Complaints> listOfComplaints = new ArrayList<>();
		CountDownLatch done = new CountDownLatch(1);
		
		databaseReference.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot dataSnapshot) {
				if (dataSnapshot.exists()) {
					Complaints complaint = dataSnapshot.getValue(Complaints.class);
					listOfComplaints.add(complaint);
					done.countDown();
				}
			}

			@Override
			public void onCancelled(DatabaseError databaseError) {
			}
		});
		try {
			done.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return listOfComplaints;
	}

//	public boolean addComplaint(String email, Complaints complaint) {
//		complaint.setUser_email(email);
//		databaseReference.setValueAsync(complaint);
//		return true;
//	}
}
