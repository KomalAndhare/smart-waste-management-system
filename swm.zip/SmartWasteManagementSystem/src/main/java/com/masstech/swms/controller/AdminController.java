package com.masstech.swms.controller;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masstech.swms.entity.Complaints;
import com.masstech.swms.entity.DailyData;
import com.masstech.swms.entity.Drivers;
import com.masstech.swms.entity.Routes;
import com.masstech.swms.entity.Stops;
import com.masstech.swms.entity.User;
import com.masstech.swms.entity.WastePickers;
import com.masstech.swms.service.ComplaintService;
import com.masstech.swms.service.DailyDataService;
import com.masstech.swms.service.DriverService;
import com.masstech.swms.service.RoutesService;
import com.masstech.swms.service.UserService;
import com.masstech.swms.service.WastePickersService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@CrossOrigin("*")
@RequestMapping("admin/")
public class AdminController {

	@Autowired
	DriverService driverService;

	@Autowired
	UserService userService;

	@Autowired
	ComplaintService complaintService;

	@Autowired
	WastePickersService wastePickersService;

	@Autowired
	DailyDataService dataService;

	@Autowired
	RoutesService routesService;

	@GetMapping("getAllUsers")
	public CompletableFuture<List<User>> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("getUser/{uId}")
	public CompletableFuture<User> getUser(@PathVariable String uId) {
		return userService.findUser(uId);
	}

	@DeleteMapping("deleteUser/{id}")
	public boolean deleteUser(@PathVariable String id) {
		return userService.deleteUser(id);
	}

	@GetMapping("getAllDrivers")
	public CompletableFuture<List<Drivers>> getAllDrivers() {
		return driverService.getAllDrivers();
	}

	@GetMapping("getDriver/{uId}")
	public CompletableFuture<Drivers> getDriver(@PathVariable String uId) {
		return driverService.findDriver(uId);
	}

	@DeleteMapping("deleteDriver/{id}")
	public boolean deleteDriver(@PathVariable String id) {
		return driverService.deleteDriver(id);
	}

	@GetMapping("getComplaints")
	public List<Complaints> getAllComplaints() {
		return complaintService.getComplaints();
	}

	@GetMapping("getDailyData/{role}/{uId}")
	public List<DailyData> getDailyData(@PathVariable String role, @PathVariable String uId) {
		return dataService.getDailyData(role, uId);
	}

	@GetMapping("getAllWastePickers")
	public List<WastePickers> getAllWastePickers() {
		return wastePickersService.getAllWatePickers();
	}

	@DeleteMapping("deleteWastePicker/{id}")
	public boolean deleteWastePicker(@PathVariable String id) {
		return wastePickersService.deleteWastePicker(id);
	}

	@GetMapping("getAllRoutes")
	public CompletableFuture<List<Routes>> getAllRoutes() {
		return routesService.getAllRoutes();
	}

	@PostMapping("setNewRoute")
	public String setRoutes(@RequestBody Routes routes) {
		return routesService.setRoutes(routes);
	}

	@PutMapping("assignRoute/{id}/{route}")
	public void postMethodName(@PathVariable String id, @PathVariable String route) {
		driverService.assignRoute(id, route);
	}

//	@PostMapping("addStop")
//	public ResponseEntity<String> addStop(@RequestBody Map<String,Stops> map) {
//		return routesService.addStop(map);
//	}

	@PutMapping("updateRoute")
	public ResponseEntity<String> addStop(@RequestBody Routes routes) {
		return routesService.updateRoutes(routes);
	}

//	@PostMapping("addComplaint/{email}")
//	public boolean postMethodName(@PathVariable String email, @RequestBody Complaints complaint) {
//		return complaintService.addComplaint(email, complaint);
//	}

	@GetMapping("driversCount")
	public CompletableFuture<Long> driversCount() {
		return driverService.driversCount();
	}

	@GetMapping("usersCount")
	public CompletableFuture<Long> usersCount() {
		return userService.usersCount();
	}

	@GetMapping("wastePickersCount")
	public CompletableFuture<Long> wastePickersCount() {
		return wastePickersService.wastePickersCount();
	}

	@PutMapping("assignArea/{id}/{area}")
	public void assignArea(@PathVariable String id, @PathVariable String area) {
		wastePickersService.assignArea(id, area);
	}

}
