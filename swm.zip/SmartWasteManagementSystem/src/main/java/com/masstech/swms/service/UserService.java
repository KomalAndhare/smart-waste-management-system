package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.Complaints;
import com.masstech.swms.entity.Drivers;
import com.masstech.swms.entity.User;

@Service
public class UserService {
	private final DatabaseReference databaseReference;

	public UserService() {
		databaseReference = FirebaseDatabase.getInstance().getReference().child("USERS");
	}

	public CompletableFuture<List<User>> getAllUsers() {
		List<User> listOfUsers = new ArrayList<>();
		CompletableFuture<List<User>> completableFuture = new CompletableFuture<List<User>>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			public void onDataChange(DataSnapshot dataSnapshot) {
				if (dataSnapshot.exists()) {
					long childrenCount = dataSnapshot.getChildrenCount();
					System.out.println(childrenCount);
					for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
						User user = snapshot.getValue(User.class);
						listOfUsers.add(user);
					}
					completableFuture.complete(listOfUsers);
				}
			}

			@Override
			public void onCancelled(DatabaseError databaseError) {
			}
		});

		return completableFuture;
	}

	public CompletableFuture<User> findUser(String uId) {
		CompletableFuture<User> completableFuture = new CompletableFuture<User>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				DataSnapshot child = snapshot.child(uId);
				if (!child.exists()) {
					return;
				}

				User user = child.getValue(User.class);
				completableFuture.complete(user);
			}

			@Override
			public void onCancelled(DatabaseError error) {
			}
		});

		return completableFuture;
	}

	public boolean deleteUser(String id) {
		databaseReference.child(id).removeValueAsync();
		return true;
	}

	public CompletableFuture<Long> usersCount() {
		CompletableFuture<Long> future = new CompletableFuture<Long>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				Long count = snapshot.getChildrenCount();
				future.complete(count);
			}

			@Override
			public void onCancelled(DatabaseError error) {
				// TODO Auto-generated method stub

			}
		});
		return future;
	}
}
