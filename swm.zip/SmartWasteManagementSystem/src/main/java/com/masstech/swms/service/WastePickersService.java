package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.User;
import com.masstech.swms.entity.WastePickers;

@Service
public class WastePickersService {

	private final DatabaseReference databaseReference;

	public WastePickersService() {

		databaseReference = FirebaseDatabase.getInstance().getReference().child("WASTE PICKERS");
	}

	public List<WastePickers> getAllWatePickers() {
		List<WastePickers> listOfWastePickers = new ArrayList<>();
		CountDownLatch done = new CountDownLatch(1);
		databaseReference.addValueEventListener(new ValueEventListener() {

			public void onDataChange(DataSnapshot dataSnapshot) {
				if (dataSnapshot.exists()) {
					for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
						WastePickers wastePickers = snapshot.getValue(WastePickers.class);
						listOfWastePickers.add(wastePickers);
						done.countDown();
					}
				}
			}

			@Override
			public void onCancelled(DatabaseError databaseError) {
			}
		});
		try {
			done.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return listOfWastePickers;
	}

	public boolean deleteWastePicker(String id) {

		CountDownLatch countDownLatch = new CountDownLatch(1);
		System.out.println(databaseReference);
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				DataSnapshot child = snapshot.child(id);
				if (!child.exists()) {
					System.out.println("WastePicker Not found");
					countDownLatch.countDown();
					return;
				}
				for (DataSnapshot data : child.getChildren()) {
					System.out.println(data);
					data.getRef().removeValueAsync();
				}
				System.out.println("WastePicker Deleted");
				countDownLatch.countDown();
			}

			@Override
			public void onCancelled(DatabaseError error) {
			}
		});

		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public CompletableFuture<Long> wastePickersCount() {
		CompletableFuture<Long> future = new CompletableFuture<Long>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				Long count = snapshot.getChildrenCount();
				future.complete(count);
			}

			@Override
			public void onCancelled(DatabaseError error) {
				// TODO Auto-generated method stub

			}
		});
		return future;
	}

	public void assignArea(String wastePickersId, String assignedArea) {
		DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("ADMIN");
		reference.child("AssignedArea").child(wastePickersId).setValueAsync(assignedArea);
	}
}
