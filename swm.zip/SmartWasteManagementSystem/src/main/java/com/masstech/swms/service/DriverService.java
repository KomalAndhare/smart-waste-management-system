package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.springframework.stereotype.Service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.Drivers;
import com.masstech.swms.entity.Routes;

@Service
public class DriverService {
	private final DatabaseReference databaseReference;

	public DriverService() {
		databaseReference = FirebaseDatabase.getInstance().getReference().child("DRIVERS");
	}

	public CompletableFuture<List<Drivers>> getAllDrivers() {
		CompletableFuture<List<Drivers>> future = new CompletableFuture<List<Drivers>>();

		databaseReference.addValueEventListener(new ValueEventListener() {

			public void onDataChange(DataSnapshot dataSnapshot) {
				if (dataSnapshot.exists()) {
					List<Drivers> listOfDrivers = new ArrayList<>();

					for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
						snapshot = snapshot.child("Info");
						Drivers driver = snapshot.getValue(Drivers.class);

						listOfDrivers.add(driver);
					}
					future.complete(listOfDrivers);
				}
			}

			@Override
			public void onCancelled(DatabaseError databaseError) {
			}
		});
		return future;
	}

	public CompletableFuture<Drivers> findDriver(String uId) {
		CompletableFuture<Drivers> completableFuture = new CompletableFuture<Drivers>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				DataSnapshot child = snapshot.child(uId);
				if (!child.exists()) {
					System.out.println("Driver Not found");
					return;
				}
				Drivers driver = child.getValue(Drivers.class);
				completableFuture.complete(driver);

				System.out.println("Driver found");
			}

			@Override
			public void onCancelled(DatabaseError error) {
			}
		});
		return completableFuture;
	}

	public boolean deleteDriver(String id) {
		databaseReference.child(id).getRef().removeValueAsync();
		return true;
	}

	public void assignRoute(String id, String routeId) {
		final DatabaseReference routeRefrence = FirebaseDatabase.getInstance().getReference().child("ROUTES");

		routeRefrence.child(routeId).addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot snapshot) {
				Routes newRoute = snapshot.getValue(Routes.class);
				DatabaseReference reference=FirebaseDatabase.getInstance().getReference();
				reference.child("ADMIN").child("AssignedRoute").child(id).setValueAsync(newRoute);
			}
			
			@Override
			public void onCancelled(DatabaseError error) {
			}
		});
	}

	public CompletableFuture<Long> driversCount() {
		CompletableFuture<Long> future = new CompletableFuture<Long>();
		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				Long count = snapshot.getChildrenCount();
				future.complete(count);
			}

			@Override
			public void onCancelled(DatabaseError error) {
			}
		});
		return future;
	}
}
