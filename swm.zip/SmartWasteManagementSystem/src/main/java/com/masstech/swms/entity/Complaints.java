package com.masstech.swms.entity;

public class Complaints {

	private String user_email;
	private String Category;
	private String Description;

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	@Override
	public String toString() {
		return "Complaints [user_email=" + user_email + ", Category=" + Category + ", Description=" + Description + "]";
	}

}
