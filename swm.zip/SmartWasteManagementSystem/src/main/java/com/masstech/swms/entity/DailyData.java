package com.masstech.swms.entity;

import java.util.Date;

public class DailyData {

	String date;
	Integer dry;
	Integer wet;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	
	public Integer getDry() {
		return dry;
	}

	public void setDry(Integer dry) {
		this.dry = dry;
	}

	public Integer getWet() {
		return wet;
	}

	public void setWet(Integer wet) {
		this.wet = wet;
	}

	@Override
	public String toString() {
		return "DailyData [date=" + date + ", dry=" + dry + ", wet=" + wet + "]";
	}

}
