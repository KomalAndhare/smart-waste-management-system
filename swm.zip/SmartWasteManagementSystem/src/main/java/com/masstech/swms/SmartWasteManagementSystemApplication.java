package com.masstech.swms;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

@SpringBootApplication
public class SmartWasteManagementSystemApplication {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		ClassLoader classLoader = SmartWasteManagementSystemApplication.class.getClassLoader();
		File file = new File(Objects.requireNonNull(classLoader.getResource("firebaseConfig.json").getFile()));
		FileInputStream fileInputStream = new FileInputStream(file.getAbsolutePath());
		FirebaseOptions firebaseOptions = new FirebaseOptions.Builder()
				.setCredentials(GoogleCredentials.fromStream(fileInputStream))
				.setDatabaseUrl("https://iotgarbage-1a979-default-rtdb.firebaseio.com/").build();

		// Check if the default FirebaseApp is already initialized
		if (FirebaseApp.getApps().isEmpty()) {
			FirebaseApp.initializeApp(firebaseOptions);
		}

		SpringApplication.run(SmartWasteManagementSystemApplication.class, args);
	}

}
