package com.masstech.swms.entity;

import java.util.List;
import java.util.Map;

public class Routes {
String routeId;
	private String startingPoint;
	private String endingPoint;
	private List<Stops> stops;

	public  List<Stops> getStops() {
		return stops;
	}


	public String getRouteId() {
		return routeId;
	}


	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}


	public void setStops( List<Stops> stops) {
		this.stops = stops;
	}

	public String getStartingPoint() {
		return startingPoint;
	}

	public void setStartingPoint(String startingPoint) {
		this.startingPoint = startingPoint;
	}

	public String getEndingPoint() {
		return endingPoint;
	}

	public void setEndingPoint(String endingPoint) {
		this.endingPoint = endingPoint;
	}

	@Override
	public String toString() {
		return "Routes [routeId=" + routeId + ", startingPoint=" + startingPoint + ", endingPoint=" + endingPoint
				+ ", stops=" + stops + "]";
	}

}
