package com.masstech.swms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.firebase.auth.FirebaseToken;
import com.masstech.swms.entity.LoginRequest;
import com.masstech.swms.service.LoginService;
//import org.json.JSONObject;

@RestController
@RequestMapping("admin/")
public class LoginController {

	@Autowired
	LoginService loginService;

//	@PostMapping("login")
//	public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest) {
//		try {
//			String firebaseResponse = loginService.loginWithEmailAndPassword(loginRequest.getEmail(),
//					loginRequest.getPassword());
////			JSONObject jsonResponse = new JSONObject(firebaseResponse);
//
//			String idToken = jsonResponse.getString("idToken");
//
//			FirebaseToken decodedToken = loginService.verifyIdToken(idToken);
//
//			String uid = decodedToken.getUid();
//
//			return ResponseEntity.status(200).body("Login successful:" + uid);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return ResponseEntity.status(401).body("Login failed:" + e.getMessage());
//		}
//	}
}
