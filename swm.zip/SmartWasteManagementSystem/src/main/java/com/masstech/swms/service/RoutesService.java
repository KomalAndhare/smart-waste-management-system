package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.google.api.gax.rpc.StatusCode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.Routes;
import com.masstech.swms.entity.Stops;

@Service
public class RoutesService {

	private final DatabaseReference databaseReference;

	public RoutesService() {
		databaseReference = FirebaseDatabase.getInstance().getReference("ROUTES");
	}

	public CompletableFuture<List<Routes>> getAllRoutes() {
		CompletableFuture<List<Routes>> future = new CompletableFuture<>();

		databaseReference.addValueEventListener(new ValueEventListener() {

			@Override
			public void onDataChange(DataSnapshot snapshot) {
				if (snapshot.exists()) {
					List<Routes> list = new ArrayList<>();
					for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
						Routes routes = dataSnapshot.getValue(Routes.class);
						list.add(routes);
					}
//					Routes routes = snapshot.getValue(Routes.class);
//					list.add(routes);
					System.out.println(list);
					future.complete(list);
				}
			}

			@Override
			public void onCancelled(DatabaseError error) {
			}
		});
		return future;
	}

	public String setRoutes(Routes routes) {
		String key = databaseReference.push().getKey();
		routes.setRouteId(key);
		databaseReference.child(key).setValueAsync(routes);
		return "Added";
	}

	public ResponseEntity<String> updateRoutes(Routes routes) {
		databaseReference.child(routes.getRouteId()).setValueAsync(routes);
		return new ResponseEntity("Route Updated", HttpStatus.OK);
	}

}
