package com.masstech.swms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import org.springframework.stereotype.Service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.masstech.swms.entity.Complaints;
import com.masstech.swms.entity.DailyData;

@Service
public class DailyDataService {

	private final FirebaseDatabase database;

	public DailyDataService() {
		database = FirebaseDatabase.getInstance();
	}

	public List<DailyData> getDailyData(String role, String uId) {
		DatabaseReference databaseReference = database.getReference(role + "/" + uId + "/Daily Data");
		List<DailyData> listOfDailyData = new ArrayList<>();
		CountDownLatch done = new CountDownLatch(1);

//		Query orderByChild = databaseReference.orderByChild("date");

		databaseReference.addValueEventListener(new ValueEventListener() {

			public void onDataChange(DataSnapshot dataSnapshot) {
				if (dataSnapshot.exists()) {
					for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
						DailyData dailyData = snapshot.getValue(DailyData.class);
						listOfDailyData.add(dailyData);
						done.countDown();

					}
				}

			}

			@Override
			public void onCancelled(DatabaseError databaseError) {
			}
		});
		try {
			done.await(); // it will wait till the response is received from firebase.
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return listOfDailyData;
	}
}