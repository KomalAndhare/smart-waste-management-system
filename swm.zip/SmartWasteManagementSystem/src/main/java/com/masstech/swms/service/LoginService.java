package com.masstech.swms.service;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;

@Service
public class LoginService {

	private final String FIREBASE_API_KEY = "AIzaSyC3QRJYv-Mx6IE5lHQzzNAyRmmEpBg2ivw";

	public String loginWithEmailAndPassword(String email, String password) {
		String url = "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + FIREBASE_API_KEY;

		String requestBody = String.format("{\"email\":\"%s\",\"password\":\"%s\",\"returnSecureToken\":true}", email,
				password);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json");

		HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);

		if (response.getStatusCode().is2xxSuccessful()) {
			return response.getBody();
		} else {
			throw new RuntimeException("Login failed with status: " + response.getStatusCode());
		}
	}

	public FirebaseToken verifyIdToken(String idToken) throws FirebaseAuthException {
		try {
			FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(idToken);
			return decodedToken;
		} catch (FirebaseAuthException e) {
			System.err.println("Error verifying ID token: " + e.getMessage());
			throw e;
		}
	}
}
